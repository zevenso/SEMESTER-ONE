#include<iostream>
#include<conio.h>

#define FILAS 50
#define COLUMNAS 3
using namespace std;

void VALORES_OFICINA( int ** matriz) {

	for (int i = 0; i < FILAS; i++) {
		for (int j = 0; j < COLUMNAS; j++) {
			matriz[i][j] = rand() % (3 - 1 + 1) + 1;
			matriz[i][1] = rand() % (30 - 1 + 1) + 1;

		}
	}
	//VALORES

	for (int i = 0; i < FILAS; i++) {
		for (int j = 0; j < COLUMNAS; j++) {
		cout << matriz[i][j] << " ";

		}
		cout << endl;
	}
	cout << endl;
}
void MAYOR_TIEMPO_LLAMADA(int **matriz) {

	int cont1 = 0, cont2 = 0, cont3 = 0; 
	

	for (int i = 0; i < FILAS; i++) {
		for (int j = 0; j < 1; j++) {

			if (matriz[i][1] > 20 && matriz[i][0] == 1){cont1 ++;}
			if (matriz[i][1] > 20 && matriz[i][0] == 2) { cont2++; }
			if (matriz[i][1] > 20 && matriz[i][0] == 3) { cont3++; }
		}
	}
	if (cont1 > cont2 && cont1 > cont3) cout << endl << "LA OFICINA CON MAYOR TIEMPO DE LLAMADAS ES : LOGISTICA";
	if (cont2 > cont3 && cont2 > cont1) cout << endl <<  "LA OFICINA CON MAYOR TIEMPO DE LLAMADAS ES : RECURSOS HUMANOS";
	if (cont3 > cont1 && cont3 > cont2) cout << endl << "LA OFICINA CON MAYOR TIEMPO DE LLAMADAS ES : VENTAS";
	if (cont1 == cont2 && cont1 > cont3 && cont2 > cont3) cout << endl << "LAS OFICINAS CON MAYOR TIEMPO DE LLAMADAS SON : LOGISTICA Y RECURSOS HUMANOS";
	if (cont1 == cont3 && cont1 > cont2 && cont3 > cont2) cout << endl <<  "LAS OFICINAS CON MAYOR TIEMPO DE LLAMADAS SON : LOGISTICA Y VENTAS";
	if (cont2 == cont3 && cont3 > cont1 && cont2 > cont1) cout << endl << "LAS OFICINAS CON MAYOR TIEMPO DE LLAMADAS SON : RECURSOS HUMANOS Y VENTAS";
	if (cont2 == cont3 && cont3 == cont1 && cont2 == cont1) cout << endl << "LAS OFICINAS CON MAYOR TIEMPO DE LLAMADAS SON : LOGISTICA, RECURSOS HUMANOS Y VENTAS";
}

void TOTAL_TIPO_LLAMADA(int** matriz) {

	float local = 0 , celu = 0, inter = 0;

	for (int i = 0; i < FILAS; i++) {
		for (int j = 0; j < 1; j++) {

			if (matriz[i][2] == 1) { local += matriz[i][1] * 0.3; }
			if (matriz[i][2] == 2) { celu += matriz[i][1] * 0.8; }
			if (matriz[i][2] == 3) { inter += matriz[i][1] * 1.5;}
		}
	}
	cout << endl << "EL MONTO TOTAL A PAGAR POR CADA TIPO DE LLAMADA ";
	cout << endl << "  - TIPO DE LLAMADA LOCAL : " << local ;
	cout << endl << "  - TIPO DE LLAMADA CELULAR : " << celu;
	cout << endl << "  - TIPO DE LLAMADA INTERNACIONAL : " << inter;
}

void TIEMPO_PROMEDIO_LLAMADAS(int** matriz) {

	int local = 0, celu = 0, inter = 0;
	int cont1 = 0, cont2 = 0, cont3 = 0;

	for (int i = 0; i < FILAS; i++) {
		for (int j = 0; j < COLUMNAS; j++) {

			if (matriz[i][0] == 3 && matriz[i][2] == 1) { cont1++;  local += matriz[i][1]; }
			if (matriz[i][0] == 3 && matriz[i][2] == 2) { cont2++; celu += matriz[i][1]; }
			if (matriz[i][0] == 3 && matriz[i][2] == 3) { cont3++; inter += matriz[i][1]; }
		}
	}
	cout << endl << "TIEMPO PROMEDIO PARA LA OFICINA DE VENTAS ";
	cout << endl << "  - TIEMPO PROMEDIO DE LLAMADAS TIPO LOCAL : " << local / cont1 << " MINUTOS";
	cout << endl << "  - TIEMPO PROMEDIO DE LLAMADAS TIPO CELULAR : " << celu / cont2 << " MINUTOS";
	cout << endl << "  - TIEMPO PROMEDIO DE LLAMADAS TIPO INTERNACIONAL : " << inter / cont3 << " MINUTOS";

}

int main() {

	// CREAR MATRIZ
	int** matriz = new int*[FILAS];
	for (int i = 0; i < FILAS; i++) {
	
		matriz[i] = new int[COLUMNAS];
	
	}

	VALORES_OFICINA(matriz);
	MAYOR_TIEMPO_LLAMADA(matriz);
	TOTAL_TIPO_LLAMADA(matriz);
	TIEMPO_PROMEDIO_LLAMADAS(matriz);
	
	for (int i = 0; i < FILAS; i++)
		delete[] matriz[i];

	delete[]matriz;

	_getch();
	return 0;
}