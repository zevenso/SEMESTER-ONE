#include<iostream>
#include<conio.h>
using namespace std;
#define FILAS 10
#define COLUMNAS 15

void asignarValores(int** matriz) {
	//rand() % (max - min + 1) + min
	for (int i = 0; i < FILAS; i++)
	{
		for (int j = 0; j < COLUMNAS; j++)
		{
			matriz[i][j] = rand() % (3 - 1 + 1) + 1;
		}
	}
}
void mostrarValores(int** matriz) {
	for (int i = 0; i < FILAS; i++)
	{
		for (int j = 0; j < COLUMNAS; j++)
		{
			cout << matriz[i][j] << " ";
		}
		cout << endl;
	}
	cout << endl;
}
void determinarFrecuencia(int** matriz) {
	int cZanahorias = 0;//1
	int cBerenjena = 0;//2
	int cNabo = 0;//3

	for (int i = 0; i < FILAS; i++)
	{
		for (int j = 0; j < COLUMNAS; j++)
		{
			switch (matriz[i][j])
			{
			case 1: cZanahorias++;	break;
			case 2:	cBerenjena++; break;
			case 3:	cNabo++; break;
			}
		}
	}
	cout << "Cantidad de Zanahorias: " << cZanahorias << endl;
	cout << "Cantidad de Berenjenas: " << cBerenjena << endl;
	cout << "Cantidad de Nabos: " << cNabo << endl;

	cout << "La verdura mas frecuente es: ";
	if (cZanahorias >= cNabo && cZanahorias >= cBerenjena) cout << "Zanahoria" << endl;
	if (cNabo >= cZanahorias && cNabo >= cBerenjena) cout << "Nabo" << endl;
	if (cBerenjena >= cZanahorias && cBerenjena >= cNabo) cout << "Berenjena" << endl;

	cout << "La verdura menos frecuente es: ";
	if (cZanahorias <= cNabo && cZanahorias <= cBerenjena) cout << "Zanahoria" << endl;
	if (cNabo <= cZanahorias && cNabo <= cBerenjena) cout << "Nabo" << endl;
	if (cBerenjena <= cZanahorias && cBerenjena <= cNabo) cout << "Berenjena" << endl;

}
void determinarGuaridaTopo(int** matriz) {
	for (int i = 1; i < FILAS - 1; i++)
	{
		for (int j = 1; j < COLUMNAS - 1; j++)
		{
			if (matriz[i - 1][j] == 3 && matriz[i][j + 1] == 2 && matriz[i + 1][j] == 1 && matriz[i][j - 1] == 2) {
				cout << "La guarida del topo esta en la posicion: " << i << " " << j << endl;
			}
		}
	}
}
int main() {
	srand(time(NULL));
	//Creamos nuestra matriz dinamica
	int** matriz = new int* [FILAS];
	for (int i = 0; i < FILAS; i++)
	{
		matriz[i] = new int[COLUMNAS];
	}
	asignarValores(matriz);
	mostrarValores(matriz);
	determinarFrecuencia(matriz);
	determinarGuaridaTopo(matriz);

	_getch();
	return 0;
}