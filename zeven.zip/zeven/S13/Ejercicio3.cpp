#include<iostream>
#include<conio.h>

using namespace std;

#define FILAS 12
#define COLUMNAS 5

void imprimirMes(int i) {
	switch (i)
	{
	case 0: cout << "ENERO"; break;
	case 1: cout << "FEBRERO"; break;
	case 2: cout << "MARZO"; break;
	case 3: cout << "ABRIL"; break;
	case 4: cout << "MAYO"; break;
	case 5: cout << "JUNIO"; break;
	case 6: cout << "JULIO"; break;
	case 7: cout << "AGOSTO"; break;
	case 8: cout << "SEPTIEMBRE"; break;
	case 9: cout << "OCTUBRE"; break;
	case 10: cout << "NOVIEMBRE"; break;
	case 11: cout << "DICIEMBRE"; break;

	}
}
void asignarValoresManualmente(int** matriz) {
	for (int i = 0; i < FILAS; i++)//meses
	{
		cout << "Ingrese las ventas del mes "; imprimirMes(i); cout << endl;
		for (int j = 0; j < COLUMNAS; j++)//agencias
		{
			cout << "Ingrese el valor de la agencia " << j + 1 << ": ";
			cin >> matriz[i][j];
		}
		cout << endl;
	}
}
void asignarValoresAleatoriamente(int** matriz) {
	for (int i = 0; i < FILAS; i++)//meses
	{
		for (int j = 0; j < COLUMNAS; j++)//agencias
		{
			matriz[i][j] = rand() % (8000 - 1000 + 1) + 1000;
		}
	}
}
void mostrarValores(int** matriz) {
	for (int i = 0; i < FILAS; i++)//meses
	{
		imprimirMes(i); cout << "  -->   ";
		for (int j = 0; j < COLUMNAS; j++)//agencias
		{
			cout << matriz[i][j] << " ";
		}
		cout << endl;
	}
}
void mostrarTotalVentasPorAgencia(int** matriz, int agencia) {
	if (agencia >= 1 && agencia <= COLUMNAS) {
		int totalVentas = 0;
		for (int i = 0; i < FILAS; i++)
		{
			totalVentas = totalVentas + matriz[i][agencia - 1];
		}
		cout << endl << "Total de ventas de la agencia " << agencia << ": " << "S/. " << totalVentas << endl;
	}
	else {
		cout << endl << "La agencia no existe" << endl;
	}
}
void mostrarTotalVentasPorMes(int** matriz, int mes) {
	if (mes >= 1 && mes <= FILAS) {
		int totalVentas = 0;
		for (int j = 0; j < COLUMNAS; j++)//agencias
		{
			totalVentas = totalVentas + matriz[mes - 1][j];
		}
		cout << endl << "Total de ventas del mes "; imprimirMes(mes - 1); cout << ": " << "S/. " << totalVentas << endl;
		cout << endl << "Promedio de ventas del mes "; imprimirMes(mes - 1); cout << ": " << "S/. " << totalVentas * 1.0 / COLUMNAS << endl;
	}
	else
	{
		cout << endl << "El mes no existe" << endl;
	}
}
void mostrarAgenciaConMayorVenta(int** matriz, int mes) {
	if (mes >= 1 && mes <= FILAS) {
		//Asumimos que la mayor venta fue de la agencia 1
		int mayorVenta = matriz[mes - 1][0];
		int agencia = 0;
		//Recorremos las agencias restantes para encontrar la mayor venta
		for (int i = 1; i < COLUMNAS; i++)//agencias
		{
			//Si la venta de la agencia i es mayor a la venta de la agencia que se supuso al inicio
			if (matriz[mes - 1][i] > mayorVenta) {
				//Se actualiza la mayor venta
				mayorVenta = matriz[mes - 1][i];
				//Se actualiza la agencia
				agencia = i;
			}
		}
		cout << endl << "La agencia con mayor venta del mes "; imprimirMes(mes - 1); cout << " es la agencia " << agencia + 1 << " : " << mayorVenta << endl;
	}
	else {
		cout << endl << "El mes no existe" << endl;
	}
}
void determinarMenorVenta(int** matriz) {
	int menorVenta = matriz[0][0];
	int agencia = 0;
	int mes = 0;
	for (int i = 0; i < FILAS; i++)
	{
		for (int j = 0; j < COLUMNAS; j++)
		{
			if (matriz[i][j] < menorVenta) {
				menorVenta = matriz[i][j];
				agencia = j;
				mes = i;
			}
		}
	}

	cout << endl << "La menor venta fue de la agencia " << agencia + 1 << " en el mes "; imprimirMes(mes); cout << " : " << menorVenta << endl;
}
int main() {
	srand(time(NULL));
	cout << endl;
	int** matriz = new int* [FILAS];
	for (int i = 0; i < FILAS; i++)
	{
		matriz[i] = new int[COLUMNAS];
	}
	asignarValoresAleatoriamente(matriz);
	mostrarValores(matriz);
	mostrarTotalVentasPorAgencia(matriz, 3);
	mostrarTotalVentasPorMes(matriz, 12);
	mostrarAgenciaConMayorVenta(matriz, 5);
	determinarMenorVenta(matriz);

	_getch();
	return 0;
}