#include <iostream>
#include <conio.h>

using namespace std;


int obtenerNValido(int limInf, int limSup) {
	int n;
	do
	{
		cout << "Ingrese valor de n: ";
		cin >> n;
	} while (n < limInf || n > limSup);
	system("cls");
	cout << "Ingrese valor de n: " << n << endl;
	return n;
}

void generarValoresMatrizCuadrada(int** M, int lado) {
	for (int i = 0; i < lado; i++)
	{
		for (int j = 0; j < lado; j++)
		{
			M[i][j] = rand() % 21;
		}
	}
}

void inicializarMatrizEnCeros(int** MR, int lado) {
	for (int i = 0; i < lado; i++)
	{
		for (int j = 0; j < lado; j++)
		{
			MR[i][j] = 0;
		}
	}
}

void imprimirMatrizCuadrada(int** M, int lado) {
	for (int i = 0; i < lado; i++)
	{
		for (int j = 0; j < lado; j++)
		{
			cout << M[i][j] << "\t";
		}
		cout << endl;
	}
	cout << endl;
}
void calcularMatrizResultante(int** M, int** MR, int lado) {
	for (int i = 1; i < lado; i++)
	{
		for (int j = 0; j < i; j++)
		{
			MR[i][j] = M[i][j] + M[j][i];
		}
	}
}
int main() {
	int n = obtenerNValido(2, 50);

	int** M, ** MR;
	M = new int* [n];
	MR = new int* [n];
	for (int i = 0; i < n; i++)
	{
		M[i] = new int[n];
		MR[i] = new int[n];
	}
	generarValoresMatrizCuadrada(M, n);
	imprimirMatrizCuadrada(M, n);
	inicializarMatrizEnCeros(MR, n);
	calcularMatrizResultante(M, MR, n);
	imprimirMatrizCuadrada(MR, n);

	_getch();
	return 0;
}