#include<iostream>
#include<conio.h>

using namespace std;

#define FILAS 6
#define COLUMNAS 8

void asignarValoresAleatoriamente(int** matriz) {
	for (int i = 0; i < FILAS; i++)
	{
		for (int j = 0; j < COLUMNAS; j++)
		{
			matriz[i][j] = rand() % (20 - 0 + 1) + 0;
		}
	}
}
void mostrarValores(int** matriz) {
	for (int i = 0; i < FILAS; i++)
	{
		for (int j = 0; j < COLUMNAS; j++)
		{
			cout << matriz[i][j] << " ";
		}
		cout << endl;
	}
	cout << endl;

}

void mostrarResultadoAnalisis(int** matriz, char** matrizAsteriscos) {
	for (int i = 1; i < FILAS - 1; i++)
	{
		for (int j = 1; j < COLUMNAS - 1; j++)
		{
			if (matriz[i][j] + matriz[i - 1][j] + matriz[i + 1][j] + matriz[i][j - 1] + matriz[i][j + 1] > 30) {
				matrizAsteriscos[i][j] = '*';
			}
			else {
				matrizAsteriscos[i][j] = ' ';
			}
		}
	}
}
void mostratResultado(char** matrizAsteriscos) {
	for (int i = 0; i < FILAS; i++)
	{
		for (int j = 0; j < COLUMNAS; j++)
		{

			if (i == 0 || i == FILAS - 1 || j == 0 || j == COLUMNAS - 1) {
				cout << " " << " ";
			}
			else {
				cout << matrizAsteriscos[i][j] << " ";

			}
		}
		cout << endl;
	}
}

void mostrarResultadoAnalisis(int** matriz) {
	for (int i = 1; i < FILAS - 1; i++)
	{
		for (int j = 1; j < COLUMNAS - 1; j++)
		{
			if (matriz[i][j] + matriz[i - 1][j] + matriz[i + 1][j] + matriz[i][j - 1] + matriz[i][j + 1] > 30) {
				cout << "*" << " ";
			}
			else {
				cout << " " << " ";
			}
		}
		cout << endl;
	}
	cout << endl;
}

int main() {
	srand(time(NULL));

 
	int** matriz = new int* [FILAS];
	for (int i = 0; i < FILAS; i++)
	{
		matriz[i] = new int[COLUMNAS];
	}
	//Matriz para almacenar los asteriscos segun la formula
	char** matrizAsteriscos = new char* [FILAS];
	for (int i = 0; i < FILAS; i++)
	{
		matrizAsteriscos[i] = new char[COLUMNAS];
	}


	asignarValoresAleatoriamente(matriz);
	mostrarValores(matriz);
	mostrarResultadoAnalisis(matriz, matrizAsteriscos);
	mostratResultado(matrizAsteriscos);
	_getch();
	return 0;
}