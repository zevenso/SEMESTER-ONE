void setTextColor(int color) {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
    /*COLORES
     0 negro
     1 azul
     2 verde
     3 aguamarina
     4 rojo
     5 purpura
     6 amarillo
     7 blanco
     8 gris
     9 azul claro
    10 verde claro
    11 cian claro o celeste
    12 rojo claro
    13 purpura claro
    14 amarillo claro
    15 blanco  */
}
#define ARRIBA 72
#define ABAJO 80
#define DERECHA 77
#define IZQUIERDA 75
#define ENTER 13