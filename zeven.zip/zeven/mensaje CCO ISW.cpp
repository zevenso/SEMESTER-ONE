#include <iostream>
#include <conio.h>

using namespace std;
using namespace System;

void Generar_Mensaje(char* Mensaje, int longitud_mensaje) {
	Random r;
	longitud_mensaje = r.Next(30, 41);

	Mensaje = new char[longitud_mensaje];

	for (int i = 0; i < longitud_mensaje; i++) {
		Mensaje[i] = r.Next(65, 90);
	}

}

void Imprimir_Mensaje(char* Mensaje, int longitud_mensaje) {
	for (int i = 0; i < longitud_mensaje; i++) {
		cout << Mensaje[i] << " ";
	}
}

bool Existe_Mensaje_CCO(char* Mensaje, int longitud_mensaje) {

	for (int i = 0; i < longitud_mensaje; i++) {
		if (Mensaje[i] == 67 && Mensaje[i + 1] == 67 && Mensaje[i + 2] == 79) {
			return true;
		}

	}

	return false;
}

bool Existe_mensaje_ISW(char* Mensaje, int longitud_mensaje) {
	for (int i = 0; i < longitud_mensaje; i++) {
		if (Mensaje[i] == 73 && Mensaje[i + 2] == 83 && Mensaje[i + 4] == 87) {
			return true;
		}

	}

	return false;
}

int main() {

	char* mensaje;
	int respuesta;
	int respuesta2;
	int longitud_mensaje;
	Random r;

	while (1) {
		longitud_mensaje = r.Next(30, 41);

		mensaje = new char[longitud_mensaje];

		for (int i = 0; i < longitud_mensaje; i++) {
			mensaje[i] = r.Next(65, 91);
		}
		for (int i = 0; i < longitud_mensaje; i++) {
			cout << mensaje[i] << " ";
		}

		respuesta = Existe_Mensaje_CCO(mensaje, longitud_mensaje);
		respuesta2 = Existe_mensaje_ISW(mensaje, longitud_mensaje);
		cout << "\n";
		if (respuesta == true) {
			cout << "ES UN ESTUDIANTE DE CIENCIAS DE LA COMPUTACION";   _getch(); // Detener al encontrar
		}
		else {
			if (respuesta2 == true) {
				cout << "ES UN ESTUDIANTE DE INGENIERIA DE SOFTWARE";   _getch(); //Detener al encontrar

			}
			else {
				cout << "Unkown";
			}
		}

		cout << "\n";

		//cout << "Presione para ver el siguiente";  _getch();  
		cout << endl << endl;

	}


	_getch();
	return 0;
}