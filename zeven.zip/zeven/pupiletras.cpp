#include<iostream>
#include<conio.h>
#include<stdio.h>
#include<time.h>

using namespace std;

using namespace System;

#define filas 10
#define columnas 10


void generar_datos(char** mat)
{
	Random dado;
	//opc1
	/*for (int i = 0; i < filas; i++)
		for (int j = 0; j < columnas; j++)
		{
			if (j % 2 == 0)
			mat[i][j] = dado.Next('0', '9' + 1);
			else
			mat[i][j] = dado.Next('A', 'Z' + 1);
		}
		*/
		//opc2
	char caracter;
	for (int i = 0; i < filas; i++)
		for (int j = 0; j < columnas; j++)
		{
			do {
				caracter = dado.Next('0', 'Z' + 1); //todo el rango a considerar
			} while (caracter >= ':' && caracter <= '@'); //validar que solo considere digitos y letras mayusculas

			mat[i][j] = caracter;
		}
}


void imprimir_datos(char** mat)
{
	for (int i = 0; i < filas; i++)
	{
		for (int j = 0; j < columnas; j++)
			//mat[i][j][k] en caso de matriz de 3 dimensiones
			cout << mat[i][j] << ' ';
		cout << endl;
	}
}



bool EsEstrellaLetras(char** luz, int posi, int posj) {

	if ((luz[posi - 1][posj] >= 'A' && luz[posi - 1][posj] <= 'Z') &&
		(luz[posi][posj - 1] >= 'A' && luz[posi][posj - 1] <= 'Z') &&
		(luz[posi][posj] >= 'A' && luz[posi][posj] <= 'Z') &&
		(luz[posi][posj + 1] >= 'A' && luz[posi][posj + 1] <= 'Z') &&
		(luz[posi + 1][posj] >= 'A' && luz[posi + 1][posj] <= 'Z'))
		return true;
	else
		return false;
}

bool EsEstrellaDigitos(char** luz, int posi, int posj) {

	if ((luz[posi - 1][posj] >= '0' && luz[posi - 1][posj] <= '9') &&
		(luz[posi][posj - 1] >= '0' && luz[posi][posj - 1] <= '9') &&
		(luz[posi][posj] >= '0' && luz[posi][posj] <= '9') &&
		(luz[posi][posj + 1] >= '0' && luz[posi][posj + 1] <= '9') &&
		(luz[posi + 1][posj] >= '0' && luz[posi + 1][posj] <= '9'))
		return true;
	else
		return false;
}

void main() {
	char** matriz;
	matriz = new char* [filas];

	for (int i = 0; i < filas; i++)
		matriz[i] = new char[columnas];


	generar_datos(matriz);
	imprimir_datos(matriz);

	//verificar si hay CRUZ LETRAS
	for (int i = 1; i < filas - 1; i++) //zona naranja delimitada
		for (int j = 1; j < columnas - 1; j++)
			if (EsEstrellaLetras(matriz, i, j))
				cout << "La estrella de letras se encuentra en la coordenada(" << i << "," << j << ")" << endl;


	//verificar si hay CRUZ DIGITOS
	for (int i = 1; i < filas - 1; i++) //zona naranja delimitada
		for (int j = 1; j < columnas - 1; j++)
			if (EsEstrellaDigitos(matriz, i, j))
				cout << endl << "La estrella de digitos se encuentra en la coordenada(" << i << "," << j << ")" << endl;


	_getch();

}